<footer>
  <p>&copy; 2025 Cosmic Book. All rights reserved.</p>
</footer>
</body>
</html>